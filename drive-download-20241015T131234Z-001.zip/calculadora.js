let operandoA;
let operandoB;
let operacion;

function init() {
    const display = document.getElementById('display');
    const btn0 = document.getElementById('btn0');
    const btn1 = document.getElementById('btn1');
    const btn2 = document.getElementById('btn2');
    const btn3 = document.getElementById('btn3');
    const btn4 = document.getElementById('btn4');
    const btn5 = document.getElementById('btn5');
    const btn6 = document.getElementById('btn6');
    const btn7 = document.getElementById('btn7');
    const btn8 = document.getElementById('btn8');
    const btn9 = document.getElementById('btn9');
    const btnDot = document.getElementById('btnDot');
    const btnAdd = document.getElementById('btnAdd');
    const btnSub = document.getElementById('btnSub');
    const btnMul = document.getElementById('btnMul');
    const btnDiv = document.getElementById('btnDiv');
    const btnEq = document.getElementById('btnEq');
    const btnClear = document.getElementById('btnClear');
    const btnReset = document.getElementById('btnReset');

    btn0.onclick = () => display.value += '0';
    btn1.onclick = () => display.value += '1';
    btn2.onclick = () => display.value += '2';
    btn3.onclick = () => display.value += '3';
    btn4.onclick = () => display.value += '4';
    btn5.onclick = () => display.value += '5';
    btn6.onclick = () => display.value += '6';
    btn7.onclick = () => display.value += '7';
    btn8.onclick = () => display.value += '8';
    btn9.onclick = () => display.value += '9';
    btnDot.onclick = () => display.value += '.';

    btnAdd.onclick = () => {
        operandoA = display.value;
        operacion = '+';
        limpiar();
    };
    btnSub.onclick = () => {
        operandoA = display.value;
        operacion = '-';
        limpiar();
    };
    btnMul.onclick = () => {
        operandoA = display.value;
        operacion = '*';
        limpiar();
    };
    btnDiv.onclick = () => {
        operandoA = display.value;
        operacion = '/';
        limpiar();
    };

    btnEq.onclick = () => resolver();
    btnClear.onclick = () => limpiar();
    btnReset.onclick = () => resetear();
}

function limpiar() {
    const display = document.getElementById('display');
    display.value = '';
}

function resetear() {
    const display = document.getElementById('display');
    display.value = '';
    operandoA = '';
    operandoB = '';
    operacion = '';
}

function resolver() {
    const display = document.getElementById('display');
    operandoB = display.value;
    let resultado = 0;

    switch (operacion) {
        case '+':
            resultado = parseFloat(operandoA) + parseFloat(operandoB);
            break;
        case '-':
            resultado = parseFloat(operandoA) - parseFloat(operandoB);
            break;
        case '*':
            resultado = parseFloat(operandoA) * parseFloat(operandoB);
            break;
        case '/':
            resultado = parseFloat(operandoA) / parseFloat(operandoB);
            break;
    }

    resetear();
    display.value = resultado;
}
